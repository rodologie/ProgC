#include <stdio.h>

int main() {
    printf("Bonjour le monde \n");
    return 0;
}
// On affiche ici directement du texte donc pas besoin de stocker quoi que soit dans une variable