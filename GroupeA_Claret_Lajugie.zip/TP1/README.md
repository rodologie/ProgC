# Bibliothèques
* stdio.h
*

# Références
* cours 
* 

# Difficulté
* break et continue dans les boucles for/ while

# Commentaires
* Première approche avec le C et utilisation des commandes basiques
* 

