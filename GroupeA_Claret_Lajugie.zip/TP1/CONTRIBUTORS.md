1. Claret Jeanne
2. Lajugie Rodolphe
