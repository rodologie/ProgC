# Bibliothèques
* stdio.h
* stdlib.h

# Références
* cours
* Dorian Isselin

# Difficulté
* 
* Sur l'exercice 3.7, ça a ete difficile de comprendre comment fonctionnait le tableau/ pointeur de la structure  et de savoir comment l'utiliser. On a aussi eu du mal à utiliser une fonction et a creer un tableau avec les couleurs distinctes.

# Commentaires
* Des difficulté (non résolues) dans l'exercice 8 à gérer les espaces pour la rceherche de phrase
* 

