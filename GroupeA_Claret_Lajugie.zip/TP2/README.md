# Bibliothèques
* stdio.h
* stdlib.h

# Références
* cours
* Discussion avec les autres binômes
* Internet pour l'exercice ptrvariables

# Difficulté
* Difficultés avec les pointeurs dans tableauptr. Je voulais d'abord utiliser l'adresse du pointeur et voir si elle etait divisible par 2 mais je n'ai pas trouve comment faire et quand j'en ai parlé à d'autre groupe, ils faisaient le test sur les indices directement. Je ne sais pas quelle méthode il fallait utiliser.
* 

# Commentaires
* Pour tableauptr, la consigne a peut-être ete mal comprise / mal applique mais nous rendons une version qui fonctionne correctement.
* 

