1. Rodolphe Lajugie
2. Jeanne Claret
